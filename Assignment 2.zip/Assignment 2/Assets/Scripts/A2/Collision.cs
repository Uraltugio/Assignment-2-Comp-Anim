using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collision : MonoBehaviour
{
    /*
    public Transform obstacle;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 toObstacle = obstacle.position - transform.position;
        float forward = Vector3.Dot(transform.forward, toObstacle.normalized);
        float right = Vector3.Dot(transform.right, toObstacle.normalized);
        //Debug.Log(forward);
        Debug.Log(right);
    }
    */
}
